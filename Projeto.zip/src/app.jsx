import React from 'react';
import { BrowserRouter, Route } from 'react-router-dom';


/* Paginas */
import Site from './site/site.jsx';
import Login from './app/login/login.jsx';
import ResetSenha from './app/ResetSenha/resetSenha.jsx';
import Home from './app/Home/home.jsx';
import Contato from './app/Contato/contato.jsx';


function App() {
  return <BrowserRouter>
    <Route exact path='/' component={Login} />
    <Route exact path='/app/site' component={Site} />
    <Route exact path='/app/esquecisenha' component={ResetSenha} />
    <Route exact path='/app/home' component={Home} />
    <Route exact path='/app/contato' component={Contato} />


  </BrowserRouter>;
}

export default App;