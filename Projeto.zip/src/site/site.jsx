import React from 'react';
import Menu from '../app/componentes/menu';
import Banner from '../app/componentes/banner';

function Site() {

    return <div>
        <Menu />
        <Banner />
    </div>
}
export default Site