import React from 'react';
import './home.css';


function Login() {
    return <div><h1>OLÁ</h1></div>
}
export default Login