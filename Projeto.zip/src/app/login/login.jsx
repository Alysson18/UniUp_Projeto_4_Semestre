import React, { useState } from 'react';
import { Link, Redirect } from 'react-router-dom';
//import firebase from '../config/firebase';
//import 'firebase/auth';
import './login.css';
import api from '../config/api';


function Login() {

    const [email, setEmail] = useState();
    const [senha, setSenha] = useState();
    const [Sucesso, setSucesso] = useState('Nulo');

    function LoginUsuario() {

        api.get("/login/user:" + email + "/password:" + senha).then(function (AxiosResponse) {
            setSucesso('S')
        }).catch(function (error) {
            setSucesso('N')
        });
        /* firebase.auth().signInWithEmailAndPassword(email, senha)
             .then(function (firebaseUser) { 
                 setSucesso('S')
             })
             .catch(function (error) {
                 setSucesso('N')
             })*/
    }

    function alterarEmail(event) {
        setEmail(event.target.value)
    }

    function alterarSenha(event) {
        setSenha(event.target.value)
    }

    return <div className="d-flex align-items-center text-center form-container">
        <form className="form-signin">
            <img className="mb-3" src="../img/Logo_Login.png" alt="" width="240" />
            <h1 className="h3 mb-3 fw-normal">Login</h1>

            <div className="form-floating">
                <input onChange={alterarEmail} type="email" className="form-control edtEmail" id="floatingInput" placeholder="Email" />
                <label for="floatingInput">E-mail</label>
            </div>
            <div className="form-floating">
                <input onChange={alterarSenha} type="password" className="form-control edtSenha" id="floatingPassword" placeholder="Senha" />
                <label for="floatingPassword">Senha</label>
            </div>

            <button onClick={LoginUsuario} className="btnLogin w-100 btn-lg mt-3" type="button">Acessar</button>
            {
                Sucesso === 'N' ? <div className="alert alert-danger mt-2"> Email ou Senha Invalidos </div> : null
            }
            {
                Sucesso === 'S' ? <Redirect to='/app/site' /> : null
            }

            <div className="login-links mt-3">
                <Link to="/app/esquecisenha" className="mx-3">Esqueci Senha</Link>
            </div>
            <p className="mt-5 mb-4 text-muted">&copy;Desenvolvido Por UNIUP</p>
        </form >
    </div>

}
export default Login