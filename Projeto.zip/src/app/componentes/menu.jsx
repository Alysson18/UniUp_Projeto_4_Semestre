import React from 'react';

function Menu() {

    return <nav className="navbar navbar-expand-md navbar-dark">

        <div className="container">

            <a className="navbar-brand" href="/app/site">
                <img src="../img/Logo_Nav-Bar_2.png" alt="" width="150" height="" />
            </a>
            <button className="navbar-toggler me-1" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse ms-4" id="navbarSupportedContent">
                <ul className="navbar-nav me-2">
                    <li className="nav-item">
                        <a className="nav-link" href="/#">Matérias</a>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link" href="/#">Quadro de Horários</a>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link" href="/#">Notas de Provas</a>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link" href="/app/contato">Contato</a>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link" href="/">Sair</a>
                    </li>

                </ul>
            </div>
        </div>
    </nav>
}
export default Menu